# BIQU B1 SE Plus (SKR 2) Firmware

Flash drive support is enabled, but jumpers to enable support may not have been installed correctly from the factory. [Follow Biqu's instructions, starting with Step 2](https://github.com/bigtreetech/BIQU-B1-SE-PLUS/blob/master/B1-SE%20fimware/B1-SE-U%20Disk%20Usage%20Tutorial-English.pdf) if flash drive support is not working correctly.
